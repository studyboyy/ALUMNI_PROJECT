<header
    class="sticky top-0 z-30 border-b border-slate-300/80 bg-white/70 shadow-sm shadow-slate-200/40 backdrop-blur-2xl">
    <div class="mx-auto flex max-w-7xl items-center justify-between gap-2 px-4 py-2 sm:px-6 lg:px-8">
        <a href="<?php echo e(route('home')); ?>" wire:navigate class="flex items-center gap-3">
            <div
                class="flex h-11 w-11 items-center justify-center rounded-2xl bg-linear-to-br from-violet-500 to-fuchsia-500 text-sm font-extrabold text-white shadow-lg shadow-violet-200/70">
                FTI</div>
            <div>
                <p class="font-display text-lg leading-none text-slate-900">Alumni FTI</p>
                <p class="text-xs uppercase tracking-[0.24em] text-slate-500">Jejaring, Karier, Kolaborasi</p>
            </div>
        </a>

        <nav class="flex flex-1 items-center justify-end gap-1 text-xs font-medium text-slate-700 sm:text-sm">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e($link['url']); ?>" wire:navigate.hover
                    <?php if($link['exact']): ?> wire:current.exact="bg-violet-100 text-violet-800" <?php else: ?> wire:current="bg-violet-100 text-violet-800" <?php endif; ?>
                    class="whitespace-nowrap rounded-full border border-slate-300/85 bg-white/70 px-2.5 py-1.5 transition hover:border-violet-300 hover:text-violet-700">
                    <?php echo e($link['label']); ?>

                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('admin.homepage')); ?>" wire:navigate
                        class="whitespace-nowrap rounded-full border border-slate-300/85 bg-white/70 px-2.5 py-1.5 text-slate-600 transition hover:border-violet-300 hover:text-violet-700">Dashboard
                        Admin</a>
                <?php else: ?>
                    <a href="<?php echo e(route('alumni.dashboard')); ?>" wire:navigate
                        class="whitespace-nowrap rounded-full border border-slate-300/85 bg-white/70 px-2.5 py-1.5 text-slate-600 transition hover:border-violet-300 hover:text-violet-700">Dashboard
                        Mahasiswa</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('register')); ?>" wire:navigate
                    class="whitespace-nowrap rounded-full bg-linear-to-r from-violet-600 to-fuchsia-500 px-2.5 py-1.5 text-white transition hover:from-violet-500 hover:to-fuchsia-400">Join</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>
    </div>
</header>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/components/navigation.blade.php ENDPATH**/ ?>