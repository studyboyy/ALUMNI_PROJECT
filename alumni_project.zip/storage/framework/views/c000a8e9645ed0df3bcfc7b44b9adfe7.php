<?php $__env->startSection('title', 'Profil Alumni FTI'); ?>

<div class="space-y-12 py-10 lg:py-14">
    <section class="section-shell grid gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        <div class="space-y-5">
            <p class="section-eyebrow">Profil Alumni FTI</p>
            <h1 class="section-title max-w-2xl">Sejarah, visi misi, struktur organisasi, dan program kerja dalam satu
                halaman yang rapi.</h1>
            <p class="section-copy">Halaman ini dirancang sebagai pusat informasi kelembagaan Ikatan Alumni FTI. Cocok
                untuk kebutuhan presentasi tugas karena seluruh elemen penting berada dalam satu narasi yang utuh.</p>
        </div>
        <div class="glass-panel space-y-4 p-6">
            <p class="font-display text-3xl text-slate-900">Visi</p>
            <p class="text-base leading-8 text-slate-600"><?php echo e($vision); ?></p>
            <div>
                <p class="mb-3 font-display text-2xl text-slate-900">Misi</p>
                <div class="space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="card-subtle text-slate-600">
                            <?php echo e($mission); ?></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="section-shell">
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Sejarah</p>
                <h2 class="section-title">Perjalanan komunitas alumni dari inisiatif sederhana menjadi organisasi yang
                    lebih terstruktur.</h2>
            </div>
        </div>
        <div class="grid gap-4 lg:grid-cols-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="glass-panel interactive-card p-5">
                    <p class="text-sm text-violet-700"><?php echo e($item['year']); ?></p>
                    <p class="mt-3 font-display text-2xl text-slate-900"><?php echo e($item['title']); ?></p>
                    <p class="mt-3 text-sm leading-7 text-slate-500"><?php echo e($item['description']); ?></p>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>

    <section class="section-shell grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div class="glass-panel p-6">
            <div class="section-heading mb-6">
                <div>
                    <p class="section-eyebrow">Struktur Organisasi</p>
                    <h2 class="section-title">Pengurus inti Ikatan Alumni FTI.</h2>
                </div>
            </div>
            <div class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $organizationMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <article class="card-subtle flex gap-4">
                        <img src="<?php echo e($member->photo_url); ?>" alt="<?php echo e($member->name); ?>"
                            class="h-20 w-20 rounded-[1.25rem] object-cover">
                        <div>
                            <p class="font-display text-2xl text-slate-900"><?php echo e($member->name); ?></p>
                            <p class="text-sm text-violet-700"><?php echo e($member->role); ?> · <?php echo e($member->division); ?></p>
                            <p class="mt-2 text-sm leading-7 text-slate-500"><?php echo e($member->focus_area); ?></p>
                            <p class="mt-2 text-xs uppercase tracking-[0.2em] text-slate-500">Periode
                                <?php echo e($member->period); ?></p>
                        </div>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        <div class="glass-panel p-6">
            <div class="section-heading mb-6">
                <div>
                    <p class="section-eyebrow">Program Kerja</p>
                    <h2 class="section-title">Program prioritas yang menjawab kebutuhan alumni dan fakultas.</h2>
                </div>
            </div>
            <div class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $workPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <article class="card-subtle">
                        <div class="flex flex-wrap items-center gap-3">
                            <span class="badge-pill"><?php echo e($program->category); ?></span>
                            <span
                                class="text-xs uppercase tracking-[0.22em] text-slate-500"><?php echo e($program->status); ?></span>
                        </div>
                        <p class="mt-4 font-display text-2xl text-slate-900"><?php echo e($program->title); ?></p>
                        <p class="mt-3 text-sm leading-7 text-slate-500"><?php echo e($program->summary); ?></p>
                        <p class="mt-3 text-sm text-violet-700">Target: <?php echo e($program->impact_target); ?></p>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/profile/index.blade.php ENDPATH**/ ?>