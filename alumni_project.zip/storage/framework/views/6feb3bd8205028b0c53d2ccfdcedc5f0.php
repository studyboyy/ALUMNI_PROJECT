<?php $__env->startSection('title', 'Berita & Agenda Alumni FTI'); ?>

<div class="space-y-12 py-10 lg:py-14">
    <section class="section-shell grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <div class="glass-panel overflow-hidden p-5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($featuredArticle): ?>
                <img src="<?php echo e($featuredArticle->cover_image_url); ?>" alt="<?php echo e($featuredArticle->title); ?>"
                    class="h-80 w-full rounded-4xl object-cover">
                <div class="mt-6 space-y-3">
                    <span class="badge-pill"><?php echo e($featuredArticle->category); ?></span>
                    <h1 class="font-display text-4xl text-slate-900"><?php echo e($featuredArticle->title); ?></h1>
                    <p class="text-base leading-8 text-slate-600"><?php echo e($featuredArticle->excerpt); ?></p>
                    <a href="<?php echo e(route('news.show', $featuredArticle)); ?>" wire:navigate class="section-link">Baca
                        selengkapnya</a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="space-y-6">
            <div class="glass-panel p-6">
                <p class="section-eyebrow">Agenda</p>
                <div class="mt-4 space-y-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <article class="card-subtle">
                            <p class="text-sm text-violet-600"><?php echo e($event->starts_at->translatedFormat('d M Y')); ?></p>
                            <p class="mt-2 font-display text-2xl text-slate-900"><?php echo e($event->title); ?></p>
                            <p class="mt-2 text-sm leading-7 text-slate-500"><?php echo e($event->summary); ?></p>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
            <div class="glass-panel p-6">
                <p class="section-eyebrow">Galeri</p>
                <div class="mt-4 grid grid-cols-2 gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $galleryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <img src="<?php echo e($item->media_url); ?>" alt="<?php echo e($item->title); ?>"
                            class="h-28 w-full rounded-[1.25rem] object-cover">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="section-shell">
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Berita Alumni</p>
                <h2 class="section-title">Kumpulan berita, prestasi, dan kegiatan terbaru.</h2>
            </div>
        </div>
        <div class="card-grid-tight lg:grid-cols-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('news.show', $article)); ?>" wire:navigate
                    class="glass-panel interactive-card block overflow-hidden p-4">
                    <img src="<?php echo e($article->cover_image_url); ?>" alt="<?php echo e($article->title); ?>"
                        class="h-48 w-full rounded-3xl object-cover">
                    <div class="mt-4 space-y-2">
                        <span class="badge-pill"><?php echo e($article->category); ?></span>
                        <p class="font-display text-2xl text-slate-900"><?php echo e($article->title); ?></p>
                        <p class="text-sm leading-7 text-slate-500"><?php echo e($article->excerpt); ?></p>
                    </div>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/news/index.blade.php ENDPATH**/ ?>