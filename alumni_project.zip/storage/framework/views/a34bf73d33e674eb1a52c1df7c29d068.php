<?php $__env->startSection('title', $newsArticle->title); ?>

<div class="space-y-12 py-10 lg:py-14">
    <section class="section-shell grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        <article class="glass-panel overflow-hidden p-5">
            <img src="<?php echo e($newsArticle->cover_image_url); ?>" alt="<?php echo e($newsArticle->title); ?>"
                class="h-96 w-full rounded-[2rem] object-cover">
            <div class="mt-6 space-y-4">
                <a href="<?php echo e(route('news.index')); ?>" wire:navigate class="section-link">Kembali ke berita & agenda</a>
                <span class="badge-pill"><?php echo e($newsArticle->category); ?></span>
                <h1 class="font-display text-5xl text-slate-900"><?php echo e($newsArticle->title); ?></h1>
                <p class="text-sm uppercase tracking-[0.22em] text-slate-500">
                    <?php echo e(optional($newsArticle->published_at)->translatedFormat('d F Y')); ?></p>
                <div
                    class="prose max-w-none space-y-4 text-base leading-8 text-slate-600 prose-headings:font-display prose-a:text-violet-700">
                    <p><?php echo e($newsArticle->excerpt); ?></p>
                    <?php echo $newsArticle->content; ?>

                </div>
            </div>
        </article>

        <aside class="glass-panel p-6">
            <p class="font-display text-3xl text-slate-900">Artikel terkait</p>
            <div class="mt-4 space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $relatedArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(route('news.show', $article)); ?>" wire:navigate
                        class="block rounded-[1.5rem] border border-slate-200 p-4 transition hover:border-violet-300">
                        <p class="text-sm text-violet-700"><?php echo e($article->category); ?></p>
                        <p class="mt-2 font-display text-2xl text-slate-900"><?php echo e($article->title); ?></p>
                        <p class="mt-2 text-sm leading-7 text-slate-500"><?php echo e($article->excerpt); ?></p>
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </aside>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/news/show.blade.php ENDPATH**/ ?>