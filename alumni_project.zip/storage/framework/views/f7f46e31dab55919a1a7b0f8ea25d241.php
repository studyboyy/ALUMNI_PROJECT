<?php $__env->startSection('title', 'Data Alumni FTI'); ?>

<div class="space-y-12 py-10 lg:py-14">
    <section class="section-shell grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div class="space-y-5">
            <p class="section-eyebrow">Data Alumni</p>
            <h1 class="section-title max-w-2xl">Direktori alumni yang bisa difilter berdasarkan angkatan, prodi, dan
                tempat kerja.</h1>
            <p class="section-copy">Semua filter di halaman ini disimpan ke URL sehingga mudah dibagikan dan konsisten
                dengan pola aplikasi Livewire modern.</p>
        </div>
        <div class="glass-panel p-6">
            <p class="font-display text-3xl text-slate-900">Statistik industri</p>
            <div class="mt-4 space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $industryStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="card-subtle flex items-center justify-between text-sm text-slate-600">
                        <span><?php echo e($item->industry); ?></span>
                        <span class="font-semibold text-slate-900"><?php echo e($item->total); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section-shell">
        <div class="glass-panel p-6">
            <div class="grid gap-4 lg:grid-cols-[1.4fr_1fr_1fr_1fr_auto]">
                <label class="space-y-2 text-sm text-slate-600">
                    <span>Cari nama atau pekerjaan</span>
                    <input wire:model.live.debounce.300ms="search" type="text" class="input-shell"
                        placeholder="Mis. Raka, engineer, Jakarta">
                </label>
                <label class="space-y-2 text-sm text-slate-600">
                    <span>Program Studi</span>
                    <select wire:model.live="program" class="input-shell">
                        <option value="">Semua prodi</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($programOption); ?>"><?php echo e($programOption); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </label>
                <label class="space-y-2 text-sm text-slate-600">
                    <span>Angkatan</span>
                    <select wire:model.live="batchYear" class="input-shell">
                        <option value="">Semua angkatan</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $batchYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </label>
                <label class="space-y-2 text-sm text-slate-600">
                    <span>Tempat kerja</span>
                    <input wire:model.live.debounce.300ms="employer" type="text" class="input-shell"
                        placeholder="Mis. Tokopedia">
                </label>
                <button wire:click="clearFilters" type="button"
                    class="rounded-full border border-slate-300 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-violet-300 hover:text-violet-700">Reset</button>
            </div>
        </div>
    </section>

    <section class="section-shell">
        <div class="card-grid-tight lg:grid-cols-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('alumni.show', $alumnus)); ?>" wire:navigate
                    class="glass-panel interactive-card block overflow-hidden p-4">
                    <img src="<?php echo e($alumnus->photo_url); ?>" alt="<?php echo e($alumnus->name); ?>"
                        class="h-60 w-full rounded-[1.5rem] object-cover">
                    <div class="mt-4 space-y-2">
                        <div class="flex items-center justify-between gap-3">
                            <p class="font-display text-2xl text-slate-900"><?php echo e($alumnus->name); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($alumnus->is_featured): ?>
                                <span class="badge-pill">Featured</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <p class="text-sm text-violet-700"><?php echo e($alumnus->program); ?> · Angkatan
                            <?php echo e($alumnus->batch_year); ?></p>
                        <p class="text-sm text-slate-500"><?php echo e($alumnus->campus_name ?: 'Kampus belum diisi'); ?></p>
                        <p class="text-sm text-slate-600"><?php echo e($alumnus->job_title); ?> di <?php echo e($alumnus->employer); ?></p>
                        <p class="text-sm leading-7 text-slate-500"><?php echo e($alumnus->city); ?>, <?php echo e($alumnus->province); ?></p>
                    </div>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="glass-panel col-span-full p-8 text-center text-slate-500">Belum ada alumni yang cocok dengan
                    filter yang dipilih.</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="mt-8"><?php echo e($alumni->links()); ?></div>
    </section>

    <section id="update-data" class="section-shell">
        <div class="glass-panel grid gap-6 p-6 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
                <p class="section-eyebrow">Update Data Alumni</p>
                <h2 class="section-title">Kelola profil alumni langsung dari dashboard internal.</h2>
                <p class="section-copy">Alumni bisa mendaftar, login, lalu memperbarui data profil tanpa perlu formulir eksternal.</p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('alumni.update-profile')); ?>" wire:navigate class="purple-btn">Update Profil Saya</a>
            <?php else: ?>
                <a href="<?php echo e(route('register')); ?>" wire:navigate class="purple-btn">Join Alumni</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/alumni/index.blade.php ENDPATH**/ ?>