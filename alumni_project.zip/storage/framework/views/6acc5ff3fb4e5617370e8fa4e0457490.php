<?php $__env->startSection('title', $alumniProfile->name); ?>

<div class="space-y-12 py-10 lg:py-14">
    <section class="section-shell grid gap-8 lg:grid-cols-[0.75fr_1.25fr]">
        <div class="glass-panel p-5">
            <img src="<?php echo e($alumniProfile->photo_url); ?>" alt="<?php echo e($alumniProfile->name); ?>"
                class="h-[28rem] w-full rounded-[2rem] object-cover">
        </div>
        <div class="space-y-6">
            <div>
                <a href="<?php echo e(route('alumni.index')); ?>" wire:navigate class="section-link">Kembali ke direktori alumni</a>
                <h1 class="mt-4 font-display text-5xl text-slate-900"><?php echo e($alumniProfile->name); ?></h1>
                <p class="mt-3 text-lg text-violet-700"><?php echo e($alumniProfile->job_title); ?> · <?php echo e($alumniProfile->employer); ?>

                </p>
                <p class="mt-2 text-slate-500"><?php echo e($alumniProfile->campus_name ?: 'Kampus belum diisi'); ?></p>
                <p class="mt-2 text-slate-500"><?php echo e($alumniProfile->program); ?> · Angkatan <?php echo e($alumniProfile->batch_year); ?>

                    · <?php echo e($alumniProfile->city); ?>, <?php echo e($alumniProfile->province); ?></p>
            </div>

            <div class="glass-panel p-6">
                <p class="font-display text-2xl text-slate-900">Biodata Singkat</p>
                <p class="mt-4 text-base leading-8 text-slate-600"><?php echo e($alumniProfile->bio); ?></p>
                <div class="mt-6 grid gap-4 sm:grid-cols-2">
                    <div class="card-subtle text-sm text-slate-600">Email:
                        <?php echo e($alumniProfile->email); ?></div>
                    <div class="card-subtle text-sm text-slate-600">Kampus:
                        <?php echo e($alumniProfile->campus_name ?: '-'); ?></div>
                    <div class="card-subtle text-sm text-slate-600">Status:
                        <?php echo e($alumniProfile->employment_status); ?></div>
                    <div class="card-subtle text-sm text-slate-600">Bidang Industri:
                        <?php echo e($alumniProfile->industry); ?></div>
                    <div class="card-subtle text-sm text-slate-600">LinkedIn: <a
                            href="<?php echo e($alumniProfile->linkedin_url); ?>" target="_blank" rel="noreferrer"
                            class="text-violet-700"><?php echo e($alumniProfile->linkedin_url); ?></a></div>
                </div>
            </div>

            <div class="glass-panel p-6">
                <p class="font-display text-2xl text-slate-900">Prestasi & Sorotan</p>
                <div class="mt-4 space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $alumniProfile->achievements ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="card-subtle text-slate-600">
                            <?php echo e($achievement); ?></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
                <blockquote class="mt-6 border-l-2 border-violet-400 pl-4 text-slate-600">
                    “<?php echo e($alumniProfile->testimonial_quote); ?>”</blockquote>
            </div>
        </div>
    </section>

    <section class="section-shell">
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Alumni Terkait</p>
                <h2 class="section-title">Alumni lain dari program studi yang sama.</h2>
            </div>
        </div>
        <div class="grid gap-6 lg:grid-cols-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $relatedAlumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('alumni.show', $related)); ?>" wire:navigate
                    class="glass-panel interactive-card block p-4">
                    <p class="font-display text-2xl text-slate-900"><?php echo e($related->name); ?></p>
                    <p class="mt-2 text-sm text-violet-700"><?php echo e($related->job_title); ?></p>
                    <p class="mt-2 text-sm text-slate-500"><?php echo e($related->employer); ?> · <?php echo e($related->city); ?></p>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/alumni/show.blade.php ENDPATH**/ ?>