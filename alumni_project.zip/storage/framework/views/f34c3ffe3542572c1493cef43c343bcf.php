<?php $__env->startSection('title', 'Dashboard Mahasiswa'); ?>

<div class="space-y-10 py-10 lg:py-14">
    <section class="section-shell grid gap-6 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
        <div class="glass-panel p-6 sm:p-8">
            <p class="section-eyebrow">Dashboard Mahasiswa</p>
            <h1 class="section-title">Kelola profil alumni dan kontribusi karier dari satu tempat.</h1>
            <p class="section-copy">Dashboard ini merangkum progres profil, status lowongan yang pernah diajukan, dan
                akses cepat ke fitur alumni.</p>

            <div class="mt-6 grid gap-4 sm:grid-cols-3">
                <article class="card-subtle">
                    <p class="text-sm text-slate-500">Profil Lengkap</p>
                    <p class="mt-2 font-display text-3xl text-slate-900"><?php echo e($completionRate); ?>%</p>
                </article>
                <article class="card-subtle">
                    <p class="text-sm text-slate-500">Lowongan Diajukan</p>
                    <p class="mt-2 font-display text-3xl text-slate-900"><?php echo e($jobStats['submitted']); ?></p>
                </article>
                <article class="card-subtle">
                    <p class="text-sm text-slate-500">Menunggu Review</p>
                    <p class="mt-2 font-display text-3xl text-slate-900"><?php echo e($jobStats['pending']); ?></p>
                </article>
            </div>

            <div class="mt-6 flex flex-wrap gap-3">
                <a href="<?php echo e(route('alumni.update-profile')); ?>" wire:navigate class="purple-btn">Update Profil</a>
                <a href="<?php echo e(route('alumni.submit-job')); ?>" wire:navigate
                    class="rounded-full border border-slate-300 px-6 py-3 font-semibold text-slate-700 transition hover:border-violet-300 hover:text-violet-700">Ajukan
                    Lowongan</a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile?->slug): ?>
                    <a href="<?php echo e(route('alumni.show', $profile->slug)); ?>" wire:navigate
                        class="rounded-full border border-slate-300 px-6 py-3 font-semibold text-slate-700 transition hover:border-violet-300 hover:text-violet-700">Lihat
                        Profil Publik</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="glass-panel p-6">
            <div class="flex items-center gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile?->photo_url): ?>
                    <img src="<?php echo e($profile->photo_url); ?>" alt="<?php echo e($profile->name); ?>"
                        class="h-20 w-20 rounded-3xl object-cover">
                <?php else: ?>
                    <div
                        class="flex h-20 w-20 items-center justify-center rounded-3xl bg-slate-200 text-2xl font-bold text-slate-500">
                        <?php echo e(auth()->user()?->initials()); ?>

                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div>
                    <p class="font-display text-2xl text-slate-900"><?php echo e($profile?->name ?? auth()->user()?->name); ?></p>
                    <p class="text-sm text-slate-500"><?php echo e($profile?->campus_name ?: 'Kampus belum diisi'); ?></p>
                    <p class="text-sm text-violet-700"><?php echo e($profile?->program ?: 'Program studi belum diisi'); ?></p>
                </div>
            </div>

            <div class="mt-6 space-y-3">
                <div class="card-subtle flex items-center justify-between text-sm text-slate-600">
                    <span>Email</span>
                    <span class="font-semibold text-slate-900"><?php echo e(auth()->user()?->email); ?></span>
                </div>
                <div class="card-subtle flex items-center justify-between text-sm text-slate-600">
                    <span>Status kerja</span>
                    <span class="font-semibold text-slate-900"><?php echo e($profile?->employment_status ?: '-'); ?></span>
                </div>
                <div class="card-subtle flex items-center justify-between text-sm text-slate-600">
                    <span>Lowongan disetujui</span>
                    <span class="font-semibold text-slate-900"><?php echo e($jobStats['approved']); ?></span>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-6">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="w-full rounded-full border border-slate-300 px-6 py-3 font-semibold text-slate-700 transition hover:border-violet-300 hover:text-violet-700">Logout</button>
            </form>
        </div>
    </section>

    <section class="section-shell grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <div class="glass-panel p-6">
            <div class="section-heading mb-6">
                <div>
                    <p class="section-eyebrow">Lowongan Terbaru</p>
                    <h2 class="section-title">Riwayat pengajuan lowongan Anda.</h2>
                </div>
                <a href="<?php echo e(route('alumni.submit-job')); ?>" wire:navigate class="section-link">Kelola lowongan</a>
            </div>

            <div class="space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <article class="card-subtle">
                        <div class="flex flex-wrap items-start justify-between gap-3">
                            <div>
                                <p class="font-semibold text-slate-900"><?php echo e($job->title); ?></p>
                                <p class="mt-1 text-sm text-slate-500"><?php echo e($job->company); ?> · <?php echo e($job->location); ?></p>
                            </div>
                            <span
                                class="rounded-full px-3 py-1 text-xs font-semibold <?php echo e($job->approval_status === 'approved' ? 'bg-emerald-50 text-emerald-700' : ($job->approval_status === 'rejected' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700')); ?>">
                                <?php echo e(ucfirst($job->approval_status)); ?>

                            </span>
                        </div>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="rounded-3xl border border-slate-200 p-4 text-sm text-slate-500">
                        Belum ada lowongan yang diajukan.
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="glass-panel p-6">
            <div class="section-heading mb-6">
                <div>
                    <p class="section-eyebrow">Langkah Berikutnya</p>
                    <h2 class="section-title">Checklist agar profil alumni Anda lebih kuat.</h2>
                </div>
            </div>

            <div class="space-y-3 text-sm text-slate-600">
                <div class="card-subtle">Lengkapi foto profil profesional.</div>
                <div class="card-subtle">Isi kampus, kota, dan posisi kerja terbaru.</div>
                <div class="card-subtle">Tambahkan LinkedIn dan pencapaian utama.</div>
                <div class="card-subtle">Ajukan lowongan jika perusahaan Anda sedang membuka posisi.</div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/alumni/dashboard.blade.php ENDPATH**/ ?>