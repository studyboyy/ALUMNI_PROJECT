<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
    data-theme="<?php echo e(\App\Models\SiteSetting::getValue('site_theme', 'coral')); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', config('app.name', 'Alumni FTI')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=playfair+display:600,700,800|poppins:400,500,600,700,800"
        rel="stylesheet" />
    <?php echo $__env->yieldPushContent('head'); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="theme-light min-h-screen bg-slate-50 text-slate-900 antialiased">
    <div class="theme-shell min-h-screen">
        <div class="theme-particles theme-particles--far" aria-hidden="true">
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
        </div>

        <div class="theme-particles theme-particles--near" aria-hidden="true">
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
            <span class="theme-particle"></span>
        </div>

        <main id="auth-content" class="relative z-10">
            <?php echo e($slot); ?>

        </main>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/layouts/auth.blade.php ENDPATH**/ ?>