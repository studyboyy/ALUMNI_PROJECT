<?php $__env->startSection('title', 'Admin Approval Lowongan'); ?>

<div class="space-y-10">
    <section>
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Admin Panel</p>
                <h1 class="section-title">Approval lowongan dari alumni.</h1>
            </div>
            <a href="<?php echo e(route('admin.alumni')); ?>" wire:navigate class="section-link">Ke kelola alumni</a>
        </div>

        <div class="glass-panel p-6">
            <label class="space-y-2 text-sm text-slate-600">
                <span>Catatan approval (opsional, dipakai untuk aksi berikutnya)</span>
                <textarea wire:model="notes" rows="3" class="input-shell" placeholder="Catatan untuk pengaju lowongan"></textarea>
            </label>
        </div>
    </section>

    <section>
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Pending</p>
                <h2 class="section-title">Lowongan menunggu persetujuan.</h2>
            </div>
        </div>

        <div class="grid gap-5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pendingJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="glass-panel p-6">
                    <div class="flex flex-wrap items-start justify-between gap-4">
                        <div>
                            <p class="font-display text-2xl text-slate-900"><?php echo e($job->title); ?></p>
                            <p class="mt-1 text-sm text-slate-600"><?php echo e($job->company); ?> · <?php echo e($job->location); ?> ·
                                <?php echo e($job->employment_type); ?></p>
                            <p class="mt-1 text-sm text-slate-500">Pengaju: <?php echo e($job->submitter?->name ?? 'Alumni'); ?></p>
                        </div>
                        <div class="flex gap-2">
                            <button wire:click="approve(<?php echo e($job->id); ?>)" type="button"
                                class="rounded-full bg-emerald-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-400">Approve</button>
                            <button wire:click="reject(<?php echo e($job->id); ?>)" type="button"
                                class="rounded-full bg-rose-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-rose-400">Reject</button>
                        </div>
                    </div>
                    <p class="mt-3 text-sm leading-7 text-slate-500"><?php echo e($job->summary); ?></p>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="glass-panel p-6 text-slate-500">Tidak ada lowongan pending saat ini.</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="mt-8"><?php echo e($pendingJobs->links()); ?></div>
    </section>

    <section>
        <div class="section-heading">
            <div>
                <p class="section-eyebrow">Riwayat Keputusan</p>
                <h2 class="section-title">Approval terbaru oleh admin.</h2>
            </div>
        </div>

        <div class="grid gap-4 lg:grid-cols-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $latestDecisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="glass-panel p-5">
                    <p class="font-display text-2xl text-slate-900"><?php echo e($decision->title); ?></p>
                    <p class="mt-2 text-sm text-slate-600">Status: <?php echo e($decision->approval_status); ?></p>
                    <p class="text-sm text-slate-500">Pengaju: <?php echo e($decision->submitter?->name ?? '-'); ?> · Admin:
                        <?php echo e($decision->approver?->name ?? '-'); ?></p>
                    <p class="mt-2 text-sm text-slate-500"><?php echo e($decision->approval_notes); ?></p>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alumni_project\resources\views/livewire/pages/admin/job-approval.blade.php ENDPATH**/ ?>